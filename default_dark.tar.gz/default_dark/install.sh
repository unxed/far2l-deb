#!/bin/bash
sudo ls
if [ $? -eq 0 ]
then
  # legacy
  cp -rf k-Colors ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/
  cp -rf highlight.ini ~/.config/far2l/
  cp -rf k-Plugins ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/
  # actual
  cp -rf settings ~/.config/far2l/
  cp -rf plugins ~/.config/far2l/
  # both
  cp -rf palette.ini ~/.config/far2l/
  sudo cp -rf hrd /usr/lib/far2l/Plugins/colorer/base/
else
  echo "Needs sudo access to write colorer scheme update" >&2
fi

