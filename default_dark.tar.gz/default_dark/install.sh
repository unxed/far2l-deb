#!/bin/bash
sudo ls
if [ $? -eq 0 ]
then
  cp -rf k-Colors ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/
  cp -rf k-Plugins ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/
  cp -rf palette.ini /home/unxed/.config/far2l/
  sudo cp -rf hrd /usr/lib/far2l/Plugins/colorer/base/
else
  echo "Needs sudo access to write colorer scheme update" >&2
fi

