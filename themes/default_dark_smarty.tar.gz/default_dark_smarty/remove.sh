#!/bin/bash
sudo ls
if [ $? -eq 0 ]
then
  rm -rf ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/k-Colors
  rm -rf ~/.config/far2l/highlight.ini
  rm -rf ~/.config/far2l/REG/HKU/c/k-Software/k-Far2/k-Plugins/k-colorer
  #
  rm -rf ~/.config/far2l/settings/colors.ini
  rm -rf ~/.config/far2l/plugins/colorer/config.ini
  #
  rm -rf ~/.config/far2l/palette.ini
  sudo cp -rf hrd/catalog-console.bak /usr/lib/far2l/Plugins/colorer/base/hrd/catalog-console.xml
else
  echo "Needs sudo access to write colorer scheme update" >&2
fi
